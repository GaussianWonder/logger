# 0.7.0

- [All] Fix Windows hook error (#1).
- [All] Add __main__ module, allowing `python -m mouse` to save and load events.


# 0.6.1

- [Windows] Fixed ctypes type-checking error.
- [All] Misc fixes to release process.


# 0.6.0

- Added README and API docs.
- Bump version to replace old library.


# 0.0.1

- Initial release, migrated from `keyboard` package.


